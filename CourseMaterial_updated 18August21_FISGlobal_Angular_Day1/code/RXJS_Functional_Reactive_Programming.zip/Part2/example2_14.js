var Bacon = require("baconjs");

Bacon
    .interval(100)
    .log()