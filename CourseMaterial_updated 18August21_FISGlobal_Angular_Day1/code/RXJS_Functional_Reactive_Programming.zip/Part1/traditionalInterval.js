setInterval(
    ()=> console.log(new Date())
,1000);
