﻿{
    let radius = 4;

    radius.
}