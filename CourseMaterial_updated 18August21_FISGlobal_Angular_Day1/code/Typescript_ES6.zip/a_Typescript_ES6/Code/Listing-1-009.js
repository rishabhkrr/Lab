var sherlock = {
    name: 'Bendict',
    heightInCentimeters: 183
};
var john = {
    name: 'Martin',
    heightInCentimeters: 169
};
