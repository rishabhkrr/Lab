var tuple;
// OK
tuple = ['my', true, 1];
// Error: 
tuple = [1, 1, 1];
