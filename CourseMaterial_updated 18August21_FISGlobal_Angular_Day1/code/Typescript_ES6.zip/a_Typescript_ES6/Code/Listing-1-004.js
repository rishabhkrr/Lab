{
    var firstName_1 = 'Chris';
    {
        var firstName_2 = 'Tudor';
        console.log('Name 1: ' + firstName_2);
    }
    console.log('Name 2: ' + firstName_1);
    // Output:
    // Name 1: Tudor
    // Name 2: Chris
}
