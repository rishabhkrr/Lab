{
    var radius_1 = 4;
    var area_1 = Math.PI * radius_1 * radius_1;
}
