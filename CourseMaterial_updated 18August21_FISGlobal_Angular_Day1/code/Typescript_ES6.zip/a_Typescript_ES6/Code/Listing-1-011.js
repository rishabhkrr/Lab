var BoxSize;
(function (BoxSize) {
    BoxSize[BoxSize["Small"] = 0] = "Small";
    BoxSize[BoxSize["Medium"] = 1] = "Medium";
})(BoxSize || (BoxSize = {}));
//...
(function (BoxSize) {
    BoxSize[BoxSize["Large"] = 2] = "Large";
    BoxSize[BoxSize["XLarge"] = 3] = "XLarge";
    BoxSize[BoxSize["XXLarge"] = 4] = "XXLarge";
})(BoxSize || (BoxSize = {}));
