﻿
// accessmodifier identifier  :type      ="value"


   const          name        : string   = 'Steve';


   



