﻿let radius = 4;
const area = Math.PI * radius * radius;

radius = 'A string'