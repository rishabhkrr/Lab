var type = 5 /* Lorry */;
